<?php
session_start();
require_once "conexion.php";

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $login = trim($_POST["login"] ?? "");
    $contrasena = trim($_POST["contrasena"] ?? "");

    if ($login === "" || $contrasena === "") {

        $mensaje = "Completa todos los campos.";

    } else if (filter_var($login, FILTER_VALIDATE_EMAIL)) {
    echo "fue un email";
    //exit;
        // LOGIN DE ESTUDIANTE
        $sql = "
            SELECT 
                MATRICULA,
                NOMBRE,
                EMAIL,
                CONTRASENA
            FROM estudiante
            WHERE EMAIL = ?
        ";


        $stmt = $pdo->prepare($sql);
    
        $stmt->execute([$login]);
        $stmt->debugDumpParams();
        //echo "<pre>";
        //print_r($stmt->errorInfo());    
        //echo "</pre>";
        //exit;
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);



        if ($usuario && password_verify($contrasena, $usuario["CONTRASENA"])) {

            $_SESSION["usuario"] = [
                "matricula" => $usuario["MATRICULA"],
                "nombre" => $usuario["NOMBRE"],
                "rol" => "alumno"
            ];

            header("Location: menu.php");
            exit;

        } else {
            $mensaje = "Correo o contraseña incorrectos.";
        }

    } else {
            echo "fue un admin";
            

        // LOGIN DE ADMINISTRADOR
        $sql = "
            SELECT 
                u.USUARIO,
                u.PWD,
                r.NOMBRE_ROL
            FROM usuario u
            INNER JOIN rol r
                ON u.ID_ROL = r.ID_ROL
            WHERE u.USUARIO = ?
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([$login]);
        $stmt->debugDumpParams();
        echo "<pre>";
        print_r($stmt->errorInfo());    
        echo "</pre>";
        //exit;

        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        echo $usuario["USUARIO"];
        echo $usuario["PWD"];
        echo $usuario["NOMBRE_ROL"];
        echo $usuario ? "si encontro usuario" : "no encontro usuario";
        echo password_verify(trim($contrasena), trim($usuario["PWD"])) ? "si coincide contraseña" : "no coincide contraseña";
        echo trim($contrasena);
        //exit;

        if ($usuario && password_verify(trim($contrasena), trim($usuario["PWD"]))) {
           // echo 'si entro admin';exit;
            $_SESSION["usuario"] = [
                "matricula" => null,
                "nombre" => $usuario["USUARIO"],
                "rol" => $usuario["NOMBRE_ROL"]
            ];

            if ($usuario["NOMBRE_ROL"] === "admin") {
                header("Location: admin.php");
            } else {
                header("Location: menu.php");
            }

            exit;

        } else {
            header("Location: login.php");
            $mensaje = "Usuario o contraseña incorrectos.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="estilos.css">
</head>

<body>

<div class="contenedor contenedor-chico">

    <h2>Iniciar sesión</h2>

    <form method="POST">

        <input 
            type="text" 
            name="login" 
            placeholder="Correo o usuario"
            required
        >

        <input 
            type="password" 
            name="contrasena" 
            placeholder="Contraseña" 
            required
        >

        <button type="submit">
            Entrar
        </button>

    </form>

    <p class="mensaje">
        <?php echo $mensaje; ?>
    </p>

    <a class="boton boton-secundario" href="registro.php">
        Crear cuenta
    </a>

</div>

</body>
</html>