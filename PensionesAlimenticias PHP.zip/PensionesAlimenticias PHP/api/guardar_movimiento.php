<?php
header('Content-Type: application/json');
require __DIR__ . '/db.php';

/* Helpers */
function s($k) {
  if (!isset($_POST[$k])) return null;
  $v = trim((string)$_POST[$k]);
  return $v === '' ? null : $v;
}
function req($k) {
  $v = s($k);
  if ($v === null) {
    echo json_encode(["ok" => false, "msg" => "Falta llenar: $k"]);
    exit;
  }
  return $v;
}
function dec($k) {
  $v = s($k);
  if ($v === null) return null;
  if (!is_numeric($v)) return null;
  return (float)$v;
}

/* 1) Requeridos (MOVIMIENTO) */
$tipo_movimiento_clase = req('tipo_movimiento_clase'); // pension | juicio
$tipo_movimiento       = req('tipo_movimiento');       // alta | cambio | baja | reintegro
$tipo_tramite          = req('tipo_tramite');          // pension | juicio

$rfc_trabajador        = req('rfc_trabajador');
$nombre_trabajador     = req('nombre_trabajador');

/* Opcionales movimiento */
$curp_trabajador = s('curp_trabajador');

/* 2) Requeridos (BENEFICIARIO) */
$ben_nombres      = req('ben_nombres');
$ben_ap_paterno   = req('ben_ap_paterno');
$ben_ap_materno   = req('ben_ap_materno');

$forma_aplicacion = req('forma_aplicacion'); // PORC_PENSION | IMP_FIJO_PENSION | JUICIO_MERCANTIL
$monto_descuento  = dec('monto_descuento');
if ($monto_descuento === null) {
  echo json_encode(["ok" => false, "msg" => "Falta llenar o inválido: monto_descuento"]);
  exit;
}

$quincena_inicio  = req('quincena_inicio');
$quincena_fin     = req('quincena_fin');

$cct_pago_beneficiario = req('cct_pago_beneficiario'); // obligatorio

/* Opcionales beneficiario */
$rfc_beneficiario     = s('rfc_beneficiario');
$celular_beneficiario = s('celular_beneficiario');
$nombre_abogado       = s('nombre_abogado');
$celular_abogado      = s('celular_abogado');

/* 3) Validaciones simples (para que no te guarden basura) */
$validClase = ['pension','juicio'];
$validMov   = ['alta','cambio','baja','reintegro'];
$validTram  = ['pension','juicio'];
$validForma = ['PORC_PENSION','IMP_FIJO_PENSION','JUICIO_MERCANTIL'];

if (!in_array($tipo_movimiento_clase, $validClase, true)) {
  echo json_encode(["ok"=>false,"msg"=>"tipo_movimiento_clase inválido"]);
  exit;
}
if (!in_array($tipo_movimiento, $validMov, true)) {
  echo json_encode(["ok"=>false,"msg"=>"tipo_movimiento inválido"]);
  exit;
}
if (!in_array($tipo_tramite, $validTram, true)) {
  echo json_encode(["ok"=>false,"msg"=>"tipo_tramite inválido"]);
  exit;
}
if ($tipo_movimiento_clase !== $tipo_tramite) {
  echo json_encode([
    "ok"=>false,
    "msg"=>"Inconsistencia: la clase interna no coincide con el tipo de trámite legal"
  ]);
  exit;
}
if (!in_array($forma_aplicacion, $validForma, true)) {
  echo json_encode(["ok"=>false,"msg"=>"forma_aplicacion inválida"]);
  exit;
}

/* 4) Transacción: beneficiario -> movimiento */
try {
  $pdo->beginTransaction();

  // A) Insert BENEFICIARIO
  $sqlBen = "
    INSERT INTO beneficiarios
    (nombres, ap_paterno, ap_materno, rfc, celular,
     forma_aplicacion, monto_descuento, quincena_inicio, quincena_fin,
     nombre_abogado, celular_abogado, cct_pago_beneficiario)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  ";
  $stmtBen = $pdo->prepare($sqlBen);
  $stmtBen->execute([
    $ben_nombres,
    $ben_ap_paterno,
    $ben_ap_materno,
    $rfc_beneficiario,
    $celular_beneficiario,
    $forma_aplicacion,
    $monto_descuento,
    $quincena_inicio,
    $quincena_fin,
    $nombre_abogado,
    $celular_abogado,
    $cct_pago_beneficiario
  ]);

  $beneficiario_id = (int)$pdo->lastInsertId();

  // B) Insert MOVIMIENTO
  $sqlMov = "
    INSERT INTO movimientos
    (estatus, tipo_movimiento_clase, tipo_movimiento, tipo_tramite,
     rfc_trabajador, curp_trabajador, nombre_trabajador,
     beneficiario_id)
    VALUES ('NUEVO', ?, ?, ?, ?, ?, ?, ?)
  ";
  $stmtMov = $pdo->prepare($sqlMov);
  $stmtMov->execute([
    $tipo_movimiento_clase,
    $tipo_movimiento,
    $tipo_tramite,
    $rfc_trabajador,
    $curp_trabajador,
    $nombre_trabajador,
    $beneficiario_id
  ]);

  $movimiento_id = (int)$pdo->lastInsertId();

  $pdo->commit();

  echo json_encode([
    "ok" => true,
    "id_movimiento" => $movimiento_id,
    "id_beneficiario" => $beneficiario_id
  ]);
} catch (Throwable $e) {
  if ($pdo->inTransaction()) $pdo->rollBack();
  echo json_encode([
    "ok" => false,
    "msg" => "Error al guardar: " . $e->getMessage()
  ]);
}
