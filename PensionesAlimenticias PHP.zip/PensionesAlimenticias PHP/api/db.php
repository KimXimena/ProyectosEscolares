<?php
ini_set('display_errors', '1');
error_reporting(E_ALL);

$host = "localhost";
$db   = "pensiones_alimenticias";
$user = "root";
$pass = "sistemas11";
$charset = "utf8mb4";

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
  PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
  $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
  http_response_code(500);
  echo json_encode([
    "ok" => false,
    "msg" => $e->getMessage()
  ]);
  exit;
}
