<?php
require __DIR__ . "/api/db.php";

$q       = trim($_GET['q'] ?? '');
$campo   = $_GET['campo'] ?? 'rfc_trabajador';
$estatus = trim($_GET['estatus'] ?? '');
$limit   = (int)($_GET['limit'] ?? 10);

$allowedCampos = ['rfc_trabajador','nombre_trabajador','nombre_beneficiario','tipo_tramite','tipo_movimiento'];
if (!in_array($campo, $allowedCampos, true)) $campo = 'rfc_trabajador';

$where  = [];
$params = [];

if ($estatus !== '') {
  $where[] = "m.estatus = :estatus";
  $params[':estatus'] = $estatus;
}

if ($q !== '') {
  if ($campo === 'nombre_beneficiario') {
    $where[] = "CONCAT_WS(' ', b.ap_paterno, b.ap_materno, b.nombres) LIKE :q";
  } else {
    $where[] = "m.$campo LIKE :q";
  }
  $params[':q'] = "%$q%";
}

$sql = "
  SELECT
    m.id,
    m.estatus,
    m.tipo_movimiento,
    m.tipo_tramite,
    m.rfc_trabajador,
    m.curp_trabajador,
    m.nombre_trabajador,
    CONCAT_WS(' ', b.ap_paterno, b.ap_materno, b.nombres) AS nombre_beneficiario,
    b.rfc AS rfc_beneficiario,
    m.creado_en
  FROM movimientos m
  INNER JOIN beneficiarios b ON b.id = m.beneficiario_id
";

if ($where) $sql .= " WHERE " . implode(" AND ", $where);
$sql .= " ORDER BY m.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 🔹 HEADERS PARA FORZAR DESCARGA EXCEL
header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=reintegros_nomina.xls");
header("Pragma: no-cache");
header("Expires: 0");

// 🔹 Tabla HTML (Excel la interpreta perfecto)
echo "<table border='1'>";
echo "<tr>
        <th>ID</th>
        <th>Estatus</th>
        <th>Tipo Movimiento</th>
        <th>Tipo Trámite</th>
        <th>RFC Trabajador</th>
        <th>CURP</th>
        <th>Nombre Trabajador</th>
        <th>Nombre Beneficiario</th>
        <th>RFC Beneficiario</th>
        <th>Fecha Captura</th>
      </tr>";

foreach ($rows as $r) {
  echo "<tr>";
  foreach ($r as $value) {
    echo "<td>" . htmlspecialchars($value) . "</td>";
  }
  echo "</tr>";
}

echo "</table>";
exit;