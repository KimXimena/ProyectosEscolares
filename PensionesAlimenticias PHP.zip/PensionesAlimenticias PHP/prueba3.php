<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Sistema de Pensión Alimenticia y Juicio Mercantil</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; font-family: "Segoe UI", system-ui, -apple-system, BlinkMacSystemFont, sans-serif; background: #f5f7fb; color: #222; }
    .topbar { background: #ffffff; border-bottom: 3px solid #e5e7eb; padding: 1rem 2.5rem 0.75rem; }
    .topbar-title { font-size: 1.5rem; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; color: #222; }
    .topbar-title span { color: #ff007c; }
    .topbar-subtitle { font-size: .8rem; color: #9ca3af; margin-top: .1rem; }
    .wrapper { max-width: 1200px; margin: 0 auto; padding: 0 1.5rem 2.5rem; }
    .filter-panel { background: #f9fafc; border: 1px solid #e5e7eb; border-radius: 4px; padding: 1rem 1.25rem 1.25rem; margin-top: 1rem; box-shadow: 0 1px 2px rgba(15,23,42,.04); }
    .filter-grid { display: grid; grid-template-columns: 2.2fr 1.6fr 1.6fr 1.2fr 1.2fr; gap: .75rem; }
    @media (max-width: 980px) { .filter-grid { grid-template-columns: 1fr 1fr; } }
    @media (max-width: 640px) { .filter-grid { grid-template-columns: 1fr; } }
    .field { margin-bottom: .45rem; }
    .field label { display: block; font-size: .75rem; font-weight: 600; text-transform: uppercase; color: #6b7280; margin-bottom: .15rem; }
    input[type="text"], input[type="date"], input[type="number"], select, textarea { width: 100%; border-radius: 3px; border: 1px solid #d1d5db; padding: .32rem .45rem; font-size: .82rem; font-family: inherit; background: #ffffff; }
    input[type="file"] { width: 100%; font-size: .8rem; }
    textarea { min-height: 70px; resize: vertical; }
    .btn { border-radius: 3px; border: none; padding: .45rem .85rem; font-size: .82rem; cursor: pointer; font-weight: 600; font-family: inherit; }
    .btn-primary { background: #00a0ff; color: #ffffff; }
    .btn-secondary { background: #f3f4f6; color: #111827; border: 1px solid #d1d5db; }
    .filter-actions { margin-top: .9rem; text-align: center; }
    .section-block { margin-top: 1.5rem; background: #ffffff; border: 1px solid #e5e7eb; border-radius: 4px; box-shadow: 0 1px 2px rgba(15,23,42,.04); }
    .section-header { background: #f5f7fb; border-bottom: 1px solid #e5e7eb; padding: .6rem 1.2rem; font-size: .8rem; font-weight: 700; text-transform: uppercase; letter-spacing: .09em; color: #4b5563; }
    .section-body { padding: 1rem 1.25rem 1.25rem; }
    .grid { display: grid; gap: .8rem; }
    .grid-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    @media (max-width: 880px) { .grid-2 { grid-template-columns: 1fr; } }
    .section-subtitle { font-size: .9rem; font-weight: 600; margin-bottom: .65rem; color: #111827; }
    .helper { font-size: .78rem; color: #6b7280; margin-bottom: .8rem; }
    .actions { margin-top: 1rem; text-align: right; }
    .row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: .8rem; }
    @media (max-width: 880px) { .row-2 { grid-template-columns: 1fr; } }
    .subcard { border: 1px solid #e5e7eb; border-radius: 4px; padding: .8rem; background: #fff; }
    .subhead { margin-bottom: .6rem; }
    .subhead-title { font-weight: 700; font-size: .85rem; color: #111827; text-transform: uppercase; letter-spacing: .06em; }
  </style>
</head>
<body>

  <!-- ENCABEZADO -->
  <div class="topbar">
    <div class="topbar-title">
      PENSIONES Y <span> JUICIO MERCANTIL.</span>
    </div>
    <div class="topbar-subtitle">
      Captura de movimientos de pensión alimenticia y juicio mercantil
    </div>
  </div>

  <div class="wrapper">

    <!-- BARRA SUPERIOR: BUSCAR + TIPO + PROCESO -->
    <div class="filter-panel">
      <div class="filter-grid">
        <div class="field">
          <label>CURP o Nombre</label>
          <input type="text" placeholder="Buscar trabajador por RFC / CURP / Nombre">
        </div>

        <div class="field">
          <label>Tipo de movimiento</label>
          <select id="tipoMovimientoClase" name="tipo_movimiento_clase">
            <option value="pension">Pensión alimenticia</option>
            <option value="juicio">Juicio mercantil</option>
          </select>
        </div>

        <div class="field">
          <label>Proceso</label>
          <select id="tipoMovimiento" name="tipo_movimiento">
            <option value="alta">Alta</option>
            <option value="cambio">Cambio</option>
            <option value="baja">Baja</option>
            <option value="reintegro">Reintegro</option>
          </select>
        </div>

        <div class="field">
          <label>Desde quincena</label>
          <input type="text" placeholder="2025-01">
        </div>

        <div class="field">
          <label>Hasta quincena</label>
          <input type="text" placeholder="2025-24">
        </div>
      </div>

      <div class="filter-actions">
        <button class="btn btn-primary" type="button">Nueva solicitud</button>
      </div>
    </div>

    <!-- BLOQUE 3: DATOS DEL TRABAJADOR-->
    <div class="section-block">
      <div class="section-header">
        CÉDULA · DATOS DEL TRABAJADOR
      </div>
      <div class="section-body">
        <div class="section-subtitle">1. Datos del trabajador</div>
        <div class="helper" id="textoTrabajador">
          Datos del trabajador de nómina sobre quien se aplicará el descuento.
        </div>

        <div class="grid grid-2">
          <div>
            <div class="field">
              <label>RFC del trabajador</label>
              <input type="text" id="rfcTrabajador" name="rfc_trabajador" placeholder="RFC del trabajador">
            </div>
            <div class="field">
              <label>CURP del trabajador</label>
              <input type="text" id="curpTrabajador" name="curp_trabajador" placeholder="CURP del trabajador">
            </div>
            <div class="field">
              <label>Nombre del trabajador</label>
              <input type="text" id="nombreTrabajador" name="nombre_trabajador" placeholder="Nombre completo del trabajador">
            </div>
          </div>

          <div>
            <div class="field">
              <label>Sostenimiento</label>
              <label style="font-size:.8rem;">
                <input type="checkbox" name="sost" value="federal"> Federal
              </label><br>
              <label style="font-size:.8rem;">
                <input type="checkbox" name="sost" value="estatal"> Estatal
              </label><br>
              <label style="font-size:.8rem;">
                <input type="checkbox" name="sost" value="burocrata"> Burocrata
              </label>
            </div>

            <div class="field">
              <label>Centro de trabajo</label>
              <input type="text" placeholder="Clave o nombre del CT">
            </div>

            <div class="field">
              <label>Consulta de nómina</label>
              <button class="btn btn-secondary" type="button" style="width:100%;" onclick="abrirNomina()">
                Ver nómina
              </button>
            </div>

            <div class="field">
              <label>Realizar cálculo automático</label>
              <button class="btn btn-primary" type="button" style="width:100%;">Calcular monto a descontar</button>
            </div>
          </div>
        </div>

        <!-- CÁLCULO ESPECÍFICO JUICIO MERCANTIL -->
        <div id="juicio-mercantil-card" style="margin-top:1.2rem; display:none;">
          <div class="section-subtitle">1.5 Cálculo específico: Juicio Mercantil</div>
          <div class="helper">
            Fórmula sugerida: (Percepciones – Descuentos de ley – Salario mínimo) × 30%.
          </div>

          <div class="grid grid-2">
            <div>
              <div class="field">
                <label>Total de percepciones</label>
                <input type="number" step="0.01">
              </div>
              <div class="field">
                <label>Descuentos de ley</label>
                <input type="number" step="0.01">
              </div>
              <div class="field">
                <label>Salario mínimo (referencia)</label>
                <input type="number" step="0.01">
              </div>
            </div>

            <div>
              <div class="field">
                <label>Cantidad total del adeudo</label>
                <input type="number" step="0.01">
              </div>
              <div class="field">
                <label>Cantidad a descontar por quincena</label>
                <input type="number" step="0.01">
              </div>
              <div class="field">
                <label>Número de quincenas estimadas</label>
                <input type="number" min="1">
              </div>
            </div>
          </div>

          <div class="field">
            <label>Detalle de descuento (concepto 66)</label>
            <textarea placeholder="El descuento se aplica al concepto 66 (Federal / Estatal)."></textarea>
          </div>
        </div>

      </div>
    </div>

    <!-- BENEFICIARIO -->
    <div class="section-block">
      <div class="section-header">
        CÉDULA · DATOS DEL BENEFICIARIO
      </div>
      <div class="section-body">
        <div class="section-subtitle">2. Datos del beneficiario</div>
        <div class="helper">
          Información de la persona que recibirá la pensión o, en su caso, del abogado para Juicio Mercantil.
        </div>

        <div class="grid grid-2">

          <!-- BENEFICIARIO -->
          <div class="subcard">
            <div class="subhead">
              <div class="subhead-title">Beneficiario</div>
            </div>

            <div class="field">
              <label>Nombre(s)</label>
              <input id="benNombres" type="text" name="ben_nombres">
            </div>

            <div class="row-2">
              <div class="field">
                <label>Apellido paterno</label>
                <input id="benApPaterno" type="text" name="ben_ap_paterno">
              </div>
              <div class="field">
                <label>Apellido materno</label>
                <input id="benApMaterno" type="text" name="ben_ap_materno">
              </div>
            </div>

            <div class="row-2">
              <div class="field">
                <label>RFC</label>
                <input id="rfcBeneficiario" type="text" name="rfc_beneficiario">
              </div>

              <div class="field">
                <label>CCT / Clave de pago del beneficiario</label>
                <select id="cctPagoBeneficiario" name="cct_pago_beneficiario" required>
                  <option value="">Selecciona…</option>
                  <option value="05KPA0035F">05KPA0035F</option>
                  <option value="05KPA0030F">05KPA0030F</option>
                  <option value="05KPA0017F">05KPA0017F</option>
                  <option value="05KPA0033F">05KPA0033F</option>
                  <option value="05KPA0032F">05KPA0032F</option>
                  <option value="05KPA0025F">05KPA0025F</option>
                  <option value="05KPA0024F">05KPA0024F</option>
                  <option value="05KPA0028F">05KPA0028F</option>
                  <option value="05KPA0002F">05KPA0002F</option>
                  <option value="05KPA0003F">05KPA0003F</option>
                </select>
              </div>
            </div>

            <div class="field">
              <label>Celular del beneficiario</label>
              <input id="celularBeneficiario" type="text" name="celular_beneficiario" placeholder="10 dígitos">
            </div>

            <div class="row-2">
              <div class="field">
                <label>Forma de aplicación</label>
                <select id="formaAplicacion" name="forma_aplicacion">
                  <option value="">Selecciona…</option>
                  <option value="PORC_PENSION">Porcentaje (Pensión)</option>
                  <option value="IMP_FIJO_PENSION">Importe fijo (Pensión)</option>
                  <option value="JUICIO_MERCANTIL">Juicio Mercantil</option>
                </select>
              </div>

              <div class="field">
                <label>Porcentaje / Importe</label>
                <input id="montoDescuento" type="number" step="0.01" name="monto_descuento" placeholder="Ej. 20 o 1500">
              </div>
            </div>

            <div class="row-2">
              <div class="field">
                <label>Quincena inicio</label>
                <input id="quincenaInicio" type="text" name="quincena_inicio" placeholder="Ej. 2025-01">
              </div>
              <div class="field">
                <label>Quincena fin</label>
                <input id="quincenaFin" type="text" name="quincena_fin" placeholder="Ej. 2025-24">
              </div>
            </div>
          </div>

          <!-- ABOGADO -->
          <div class="subcard">
            <div class="subhead">
              <div class="subhead-title">Abogado</div>
            </div>

            <div class="field">
              <label>Nombre completo</label>
              <input id="nombreAbogado" type="text" name="nombre_abogado" placeholder="Nombre completo del abogado">
            </div>

            <div class="field">
              <label>Celular del abogado</label>
              <input id="celularAbogado" type="text" name="celular_abogado" placeholder="10 dígitos">
            </div>
          </div>

        </div>
      </div>
    </div>

    <!--BLOQUE 1: DATOS DEL OFICIO-->
    <div class="section-block">
      <div class="section-header">
        CÉDULA · DATOS DEL OFICIO
      </div>
      <div class="section-body">
        <div class="section-subtitle" id="tituloOficio">
          3. Datos del oficio
        </div>

        <div class="grid grid-2">
          <div>
            <div class="field">
              <label>Tipo de trámite</label>
              <select id="tipoTramite" name="tipo_tramite">
                <option value="">Selecciona…</option>
                <option value="pension">Pensión alimenticia</option>
                <option value="juicio">Juicio mercantil</option>
              </select>
            </div>

            <div class="field">
              <label>Número de oficio</label>
              <input type="text" placeholder="Ej. 1234/2025">
            </div>

            <div class="field">
              <label>Fecha del oficio</label>
              <input type="date">
            </div>

            <div class="field">
              <label>Fecha de recibido</label>
              <input type="date">
            </div>
          </div>

          <div>
            <div class="field">
              <label>Cargar archivo del oficio</label>
              <input type="file" accept=".pdf,image/*">
            </div>

            <div class="field">
              <label>Número de expediente en el juzgado</label>
              <input type="text">
            </div>

            <div class="field">
              <label>Juzgado</label>
              <select id="juzgado" name="juzgado">
                <option value="">Selecciona…</option>

                <optgroup label="Distrito Judicial de Saltillo">
                  <option>Juzgado Primero de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado Segundo de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado Tercero de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado Cuarto de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado de Primera Instancia en Materia de Familia (Especializado en Violencia Familiar)</option>
                  <option>Juzgado Primero de Primera Instancia en Materia de Juicio Letrado Civil y Familiar</option>
                  <option>Juzgado Segundo de Primera Instancia en Materia de Juicio Letrado Civil y Familiar</option>
                </optgroup>

                <optgroup label="Distrito Judicial de Torreón">
                  <option>Juzgado Primero de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado Segundo de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado Tercero de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado Cuarto de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado Quinto de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado de Primera Instancia en Materia de Familia (Especializado en Violencia Familiar)</option>
                  <option>Juzgado Primero de Primera Instancia en Materia de Juicio Letrado Civil y Familiar</option>
                  <option>Juzgado Segundo de Primera Instancia en Materia de Juicio Letrado Civil y Familiar</option>
                </optgroup>

                <optgroup label="Distrito Judicial de Monclova">
                  <option>Juzgado Primero de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado Segundo de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado de Primera Instancia en Materia de Juicio Letrado Civil y Familiar</option>
                </optgroup>

                <optgroup label="Distrito Judicial de Río Grande (Piedras Negras)">
                  <option>Juzgado Primero de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado Segundo de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado de Primera Instancia en Materia de Juicio Letrado Civil y Familiar</option>
                </optgroup>

                <optgroup label="Distrito Judicial de Acuña">
                  <option>Juzgado de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado de Primera Instancia en Materia de Juicio Letrado Civil y Familiar</option>
                </optgroup>

                <optgroup label="Distrito Judicial de la Región Carbonífera (Sabinas)">
                  <option>Juzgado de Primera Instancia en Materia Familiar</option>
                  <option>Juzgado de Primera Instancia en Materia de Juicio Letrado Civil y Familiar</option>
                </optgroup>

                <optgroup label="Distrito Judicial de San Pedro">
                  <option>Juzgado de Primera Instancia en Materia Civil y Familiar</option>
                  <option>Juzgado de Primera Instancia en Materia de Juicio Letrado Civil y Familiar</option>
                </optgroup>

                <optgroup label="Distrito Judicial de Parras">
                  <option>Juzgado de Primera Instancia en Materia Civil y Familiar</option>
                  <option>Juzgado de Primera Instancia en Materia de Juicio Letrado Civil y Familiar</option>
                </optgroup>

                <optgroup label="Juzgados Externos">
                  <option>Externos</option>
                </optgroup>
              </select>
            </div>

            <div class="field">
              <label>Municipio de pago</label>
              <select id="municipio_pago" name="municipio_pago">
                <option value="">Selecciona…</option>

                <optgroup label="Municipios Coahuila">
                  <option value="001">001 — Abasolo</option>
                  <option value="002">002 — Acuña</option>
                  <option value="003">003 — Allende</option>
                  <option value="004">004 — Arteaga</option>
                  <option value="005">005 — Candela</option>
                  <option value="006">006 — Castaños</option>
                  <option value="007">007 — Cuatro Ciénegas</option>
                  <option value="008">008 — Escobedo</option>
                  <option value="009">009 — Francisco I. Madero</option>
                  <option value="010">010 — Frontera</option>
                  <option value="011">011 — General Cepeda</option>
                  <option value="012">012 — Guerrero</option>
                  <option value="013">013 — Hidalgo</option>
                  <option value="014">014 — Jiménez</option>
                  <option value="015">015 — Juárez</option>
                  <option value="016">016 — Lamadrid</option>
                  <option value="017">017 — Matamoros</option>
                  <option value="018">018 — Monclova</option>
                  <option value="019">019 — Morelos</option>
                  <option value="020">020 — Múzquiz</option>
                  <option value="021">021 — Nadadores</option>
                  <option value="022">022 — Nava</option>
                  <option value="023">023 — Ocampo</option>
                  <option value="024">024 — Parras</option>
                  <option value="025">025 — Piedras Negras</option>
                  <option value="026">026 — Progreso</option>
                  <option value="027">027 — Ramos Arizpe</option>
                  <option value="028">028 — Sabinas</option>
                  <option value="029">029 — Sacramento</option>
                  <option value="030">030 — Saltillo</option>
                  <option value="031">031 — San Buenaventura</option>
                  <option value="032">032 — San Juan de Sabinas</option>
                  <option value="033">033 — San Pedro</option>
                  <option value="034">034 — Sierra Mojada</option>
                  <option value="035">035 — Torreón</option>
                  <option value="036">036 — Viesca</option>
                  <option value="037">037 — Villa Unión</option>
                  <option value="038">038 — Zaragoza</option>
                </optgroup>

                <optgroup label="Municipio Externo">
                  <option value="000">000 - Externo</option>
                </optgroup>
              </select>
            </div>
          </div>
        </div>

        <div class="actions"></div>
      </div>
    </div>

    <!-- Un solo bloque final de acciones -->
    <div class="actions">
      <button class="btn btn-primary" type="button" id="btnGuardar">Guardar movimiento</button>
      <a href="prueba3.1.php" class="btn btn-secondary">Ir a seguimiento</a>
    </div>

  </div>

  <script>
    const btnGuardar = document.getElementById("btnGuardar");

    btnGuardar.addEventListener("click", async () => {
      try {
        // MOVIMIENTO
        const tipoTramite = document.getElementById("tipoTramite").value;
        const proceso     = document.getElementById("tipoMovimiento").value;
        const clase       = document.getElementById("tipoMovimientoClase").value;

        const rfcTrab  = document.getElementById("rfcTrabajador").value.trim();
        const nomTrab  = document.getElementById("nombreTrabajador").value.trim();
        const curpTrab = document.getElementById("curpTrabajador").value.trim();

        // BENEFICIARIO
        const benNombres   = document.getElementById("benNombres").value.trim();
        const benApPaterno = document.getElementById("benApPaterno").value.trim();
        const benApMaterno = document.getElementById("benApMaterno").value.trim();

        const rfcBen = document.getElementById("rfcBeneficiario").value.trim();
        const celBen = document.getElementById("celularBeneficiario").value.trim();

        const formaAplicacion = document.getElementById("formaAplicacion").value; 
        const montoDescuento  = document.getElementById("montoDescuento").value.trim();

        const quincenaInicio  = document.getElementById("quincenaInicio").value.trim();
        const quincenaFin     = document.getElementById("quincenaFin").value.trim();

        const nombreAbogado  = document.getElementById("nombreAbogado").value.trim();
        const celularAbogado = document.getElementById("celularAbogado").value.trim();

        const cctPago = document.getElementById("cctPagoBeneficiario").value.trim();

        // Validación mínima obligatoria
        if (!tipoTramite || !proceso || !clase || !rfcTrab || !nomTrab) {
          alert("Falta llenar: Tipo de trámite, Proceso, RFC y Nombre del trabajador.");
          return;
        }

        if (!benNombres || !benApPaterno) {
          alert("Falta llenar: Nombre(s) y Apellido paterno del beneficiario.");
          return;
        }

        if (!formaAplicacion) {
          alert("Falta seleccionar: Forma de aplicación.");
          return;
        }

        if (!montoDescuento || isNaN(Number(montoDescuento))) {
          alert("Falta llenar o inválido: Porcentaje o Importe.");
          return;
        }

        if (!quincenaInicio || !quincenaFin) {
          alert("Falta llenar: Quincena inicio y Quincena fin.");
          return;
        }

        if (!cctPago) {
          alert("Falta llenar: CCT pago beneficiario.");
          return;
        }

        const fd = new FormData();

        // MOVIMIENTO
        fd.append("tipo_movimiento_clase", clase);
        fd.append("tipo_movimiento", proceso);
        fd.append("tipo_tramite", tipoTramite);

        fd.append("rfc_trabajador", rfcTrab);
        fd.append("curp_trabajador", curpTrab);
        fd.append("nombre_trabajador", nomTrab);

        // BENEFICIARIO
        fd.append("ben_nombres", benNombres);
        fd.append("ben_ap_paterno", benApPaterno);
        fd.append("ben_ap_materno", benApMaterno);

        fd.append("rfc_beneficiario", rfcBen);
        fd.append("celular_beneficiario", celBen);

        fd.append("forma_aplicacion", formaAplicacion);
        fd.append("monto_descuento", montoDescuento);
        fd.append("quincena_inicio", quincenaInicio);
        fd.append("quincena_fin", quincenaFin);

        // Abogado
        fd.append("nombre_abogado", nombreAbogado);
        fd.append("celular_abogado", celularAbogado);

        // CCT
        fd.append("cct_pago_beneficiario", cctPago);

        const resp = await fetch("api/guardar_movimiento.php", {
          method: "POST",
          body: fd
        });

        const text = await resp.text();
        let data;
        try { data = JSON.parse(text); }
        catch { throw new Error("Respuesta no-JSON del servidor: " + text); }

        if (!resp.ok) throw new Error(data.msg || ("HTTP " + resp.status));

        if (data.ok) {
          alert("Guardado.\nMovimiento ID: " + data.id_movimiento + "\nBeneficiario ID: " + data.id_beneficiario);
        } else {
          alert("No se guardó: " + (data.msg || "Error"));
        }

      } catch (err) {
        alert("Falló el guardado: " + err.message);
        console.error(err);
      }
    });

    function abrirNomina(){
      const rfc  = document.getElementById("rfcTrabajador").value.trim();
      const curp = document.getElementById("curpTrabajador").value.trim();
      const nom  = document.getElementById("nombreTrabajador").value.trim();

      let url = "nomina.php";
      const params = new URLSearchParams();
      if (rfc)  params.set("rfc", rfc);
      if (curp) params.set("curp", curp);
      if (nom)  params.set("nombre", nom);

      const qs = params.toString();
      if (qs) url += "?" + qs;

      window.open(url, "_blank", "noopener");
    }
  </script>

</body>
</html>