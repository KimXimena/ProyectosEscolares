<?php
require __DIR__ . "/api/db.php";

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$quincena = trim($_GET['quincena'] ?? '');
$mov      = strtolower(trim($_GET['mov'] ?? '')); // alta | cambio | baja | '' (todos)
$allowed  = ['', 'alta', 'cambio', 'baja'];
if (!in_array($mov, $allowed, true)) $mov = '';

$rows = [];

if ($quincena !== '') {

  $where  = [];
  $params = [];

  // 🔧 FIX HY093: no reutilizar el mismo :q dos veces (usa :q1 y :q2)
  // Quincena "dentro de rango" [inicio, fin]
  $where[] = "(:q1 >= b.quincena_inicio AND :q2 <= b.quincena_fin)";
  $params[':q1'] = $quincena;
  $params[':q2'] = $quincena;

  // Filtro por tipo de movimiento (m)
  if ($mov !== '') {
    $where[] = "m.tipo_movimiento = :mov";
    $params[':mov'] = $mov;
  }

  $sql = "
    SELECT
      m.id,
      m.tipo_movimiento,
      m.tipo_tramite,
      m.rfc_trabajador,
      m.curp_trabajador,
      m.nombre_trabajador,
      m.estatus,

      b.quincena_inicio,
      b.quincena_fin,
      CONCAT_WS(' ', b.ap_paterno, b.ap_materno, b.nombres) AS nombre_beneficiario,
      b.rfc AS rfc_beneficiario

    FROM movimientos m
    INNER JOIN beneficiarios b ON b.id = m.beneficiario_id
    WHERE ".implode(" AND ", $where)."
    ORDER BY m.id DESC
  ";

  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function movTxt($m){
  return $m==='alta'?'ALTA':($m==='cambio'?'CAMBIOS':($m==='baja'?'BAJA':'—'));
}
function tramTxt($t){
  return $t==='pension'?'Pensión alimenticia':($t==='juicio'?'Juicio mercantil':'—');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>SIAPSEP · Consulta</title>
<style>
body{margin:0;font-family:"Segoe UI",system-ui;background:#f3f4f6}
.page{max-width:1200px;margin:0 auto;padding:1.5rem}
header{border-bottom:2px solid #e5e7eb;margin-bottom:1rem}
h1{margin:0;font-size:1.6rem;letter-spacing:.04em}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:4px;padding:1rem 1.25rem;margin-bottom:1rem}
label{font-size:.75rem;font-weight:700;text-transform:uppercase;color:#6b7280}
input{width:100%;padding:.4rem;border:1px solid #cbd5e1;border-radius:3px}
.actions{text-align:right;margin-top:.75rem}
.btn{border:none;border-radius:3px;padding:.35rem .8rem;font-size:.8rem;font-weight:700;cursor:pointer;text-decoration:none;display:inline-block}
.btn-primary{background:#007bff;color:#fff}
.btn-ghost{background:#f3f4f6;border:1px solid #d1d5db;color:#111827}
.filters{display:flex;gap:.4rem;flex-wrap:wrap}
table{width:100%;border-collapse:collapse;font-size:.8rem}
th,td{border-bottom:1px solid #e5e7eb;padding:.45rem;text-align:left;vertical-align:top}
thead{background:#f1f5f9}
tbody tr:nth-child(even){background:#f9fafb}
.muted{color:#6b7280}
</style>
</head>
<body>
<div class="page">

<header>
  <h1>SIAPSEP · Consulta por Quincena</h1>
</header>

<!-- RECUADRO 1: QUINCENA -->
<div class="card">
  <form method="GET">
    <label>Quincena de Proceso</label>
    <input type="text" name="quincena" value="<?=h($quincena)?>" placeholder="Ej. 2025-01" required>
    <div class="actions">
      <button class="btn btn-primary">Buscar</button>
    </div>
  </form>
</div>

<?php if ($quincena !== ''): ?>

<!-- RECUADRO 2: FILTROS -->
<div class="card">
  <strong>Quincena:</strong> <?=h($quincena)?>
  <div class="filters" style="margin-top:.5rem;">
    <a class="btn <?= $mov===''?'btn-primary':'btn-ghost' ?>" href="?quincena=<?=h($quincena)?>">TODOS</a>
    <a class="btn <?= $mov==='alta'?'btn-primary':'btn-ghost' ?>" href="?quincena=<?=h($quincena)?>&mov=alta">ALTA</a>
    <a class="btn <?= $mov==='cambio'?'btn-primary':'btn-ghost' ?>" href="?quincena=<?=h($quincena)?>&mov=cambio">CAMBIOS</a>
    <a class="btn <?= $mov==='baja'?'btn-primary':'btn-ghost' ?>" href="?quincena=<?=h($quincena)?>&mov=baja">BAJA</a>
  </div>
</div>

<!-- RECUADRO 3: TABLA -->
<div class="card" style="overflow-x:auto;">
<table>
<thead>
<tr>
  <th>ID</th>
  <th>Movimiento</th>
  <th>Trámite</th>
  <th>Beneficiario</th>
  <th>RFC Beneficiario</th>
  <th>RFC Trabajador</th>
  <th>CURP</th>
  <th>Nombre Trabajador</th>
  <th>Qna Inicio</th>
  <th>Qna Fin</th>
  <th>Estatus</th>
</tr>
</thead>
<tbody>
<?php if (!$rows): ?>
<tr><td colspan="11" class="muted">No hay registros para esta quincena.</td></tr>
<?php else: foreach ($rows as $r): ?>
<tr>
  <td><?=h($r['id'])?></td>
  <td><?=h(movTxt($r['tipo_movimiento']))?></td>
  <td><?=h(tramTxt($r['tipo_tramite']))?></td>
  <td><?=h($r['nombre_beneficiario'])?></td>
  <td><?=h($r['rfc_beneficiario'])?></td>
  <td><?=h($r['rfc_trabajador'])?></td>
  <td><?=h($r['curp_trabajador'])?></td>
  <td><?=h($r['nombre_trabajador'])?></td>
  <td><?=h($r['quincena_inicio'])?></td>
  <td><?=h($r['quincena_fin'])?></td>
  <td><?=h($r['estatus'])?></td>
</tr>
<?php endforeach; endif; ?>
</tbody>
</table>
</div>

<?php endif; ?>

</div>
</body>
</html>